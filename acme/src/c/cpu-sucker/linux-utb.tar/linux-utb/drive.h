
extern int unmount( char *directory );
