/*
 * power_off
 *
 * APIs to handle the power.
 */

extern int power_off();
